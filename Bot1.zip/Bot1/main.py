from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import ReplyKeyboardMarkup, ReplyKeyboardRemove, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

button1 = InlineKeyboardButton(text="Yes", callback_data="Can you type what server is Down?")
button2 = InlineKeyboardButton(text="No", callback_data="I have other fun commands")
keyboard_inline = InlineKeyboardMarkup().add(button1, button2)

bot = Bot(token='5576291415:AAEBkR4erCvloDuHEoIkax136aw0YExpmtQ')
dp = Dispatcher(bot)


@dp.message_handler(commands=['server'])
async def server_status(message: types.Message):
    await message.reply("Is a Server Down?",reply_markup=keyboard_inline)
    

@dp.message_handler(commands=['start', 'help'])
async def welcome(message: types.Message):
    await message.reply("Hi! Im Server Reports Bot,How can i help you today?")


@dp.callback_query_handler(text= ["Yes", "No"])
async def status(call: types.CallbackQuery):
    if call.data == "Yes":
        await call.message.answer("Your input has been recorded")
    if call.data == "No":
        await call.message.answer("Are you sure no server is down")
    await call.answer()

executor.start_polling(dp)

